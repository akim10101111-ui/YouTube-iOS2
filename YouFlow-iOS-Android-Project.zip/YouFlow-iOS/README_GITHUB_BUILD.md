# YouFlow — GitHub build package

This is the supplied YouFlow Android source tree, packaged for upload to your
`YouTube-iOS` GitHub repository. The original project files are retained.

## Upload through GitHub Codespaces

1. Open the `YouTube-iOS` repository and start a Codespace.
2. Upload this ZIP into the Codespace workspace.
3. In the terminal, run:

   ```bash
   unzip YouFlow-YouTube-iOS-Final.zip
   ```

4. Copy the extracted project's contents into the repository root (not the
   outer folder), then commit and push:

   ```bash
   cp -a YouFlow-YouTube-iOS/. .
   git add .
   git commit -m "Add YouFlow Android project"
   git push
   ```

5. Open the repository's **Actions** tab. The workflow **Build Android APK**
   runs on push or can be started with **Run workflow**.
6. When it succeeds, open the run, scroll to **Artifacts**, and download
   `YouFlow-debug-apk`.

## Build notes

- The app uses NewPipeExtractor as an included Gradle build. A ZIP upload does
  not preserve Git submodule metadata, so the workflow fetches the exact
  extractor revision referenced by the project's version catalog.
- The workflow produces a **debug APK**, not a Play Store-signed release.
- This package does not claim that the APK has already been built or tested.
